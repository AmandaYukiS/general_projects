from flask import Flask, request, render_template
import requests
import os

app = Flask(__name__)
API_KEY = os.environ.get("OWM_API_KEY")

@app.route("/", methods=["GET", "POST"])

def home():
    weather = None
    if request.method == 'POST':
        city = request.form['city']
        print(f"Cidade recebida: {city}")  # ← Aparecerá no terminal
        weather = get_weather(city)
        print(f"Dados do clima: {weather}")  # ← Debug
    return render_template('weather.html', weather = weather)
def get_weather(city):
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
    response = requests.get(url)
    data = response.json()

    if data['cod'] == 200:
        return {
            'city': data['name'],
            'temp': data['main']['temp'],
            'description': data['weather'][0]['description']
        }
    else:
        return {"error": "City Not Found!"}

if __name__ == "__main__":
    app.run(debug=True)